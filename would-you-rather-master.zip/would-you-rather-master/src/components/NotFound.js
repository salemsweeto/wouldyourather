import React, { Component } from 'react';

class NotFound extends Component {
  render() {
    return (
      <div>
        <h3 className='center'>404 / Not Found</h3>
      </div>
    );
  }
}

export default NotFound